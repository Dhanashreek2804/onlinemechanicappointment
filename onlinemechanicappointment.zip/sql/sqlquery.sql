create table customer(
cutomerid int AUTO_INCREMENT PRIMARY KEY,
name varchar(200) NOT NULL,
address varchar(200) NOT NULL,
phoneNo INT
);

select * from customer;