create table appointment(
appid int AUTO_INCREMENT PRIMARY KEY,
date DATETIME NOT NULL,
vehiclename varchar(200),
vehiclenNO varchar(200),
customername varchar(200),
servicetype varchar(190),
customerid int ,
CONSTRAINT FK_customerid FOREIGN KEY(customerid) REFERENCES Customer(cutomerid) 
);