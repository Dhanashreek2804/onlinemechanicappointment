package com.mechanicapp.dao.impl;

 
import java.sql.Connection;
 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mechanicapp.dao.ClientDao;
import com.mechanicapp.exception.AppointmentNotFoundException;
import com.mechanicapp.exception.ClientNotFoundException;
import com.mechanicapp.model.Appointment;
import com.mechanicapp.model.Client;
import com.mechanicapp.util.DbUtil;

public class ClientDaoImpl implements ClientDao {
	
		private final static String SELECT_ALL = "SELECT * FROM CUSTOMER";
		private final static String SELECT_ALL_APPOINMENT = "SELECT * FROM Appointment";
		
		private final static String SELECT_BY_ID = "SELECT * FROM CUSTOMER WHERE customerid=?";
		private final static String SELECT_BY_ID_APPOINTMENT = "SELECT * FROM Appointment WHERE customerid=?";
		
		private final static String INSERT = "insert into customer(name,address, phoneNO) values(?,?,?)";
		private final static String INSERT_APPOINTMENT = "insert into Appointment(date,vehiclename, vehiclenNO, customername, servicetype,customerid) values(?,?,?,?,?,?,?,?)";
		
		private final static String UPDATE = "UPDATE CUSTOMER SET Name=?, address=?, phoneNO=? WHERE customerid=?";
		private final static String UPDATE_APPOINTMENT = "UPDATE Appointment SET date=3?,vehiclename=?,vehiclenNO=?, customername=?, servicetype=? WHERE customerid=?";
		
		private final static String DELETE = "DELETE FROM CUSTOMER WHERE customerid = ? ";
		private final static String DELETE_APPOINTMENT = "DELETE FROM Appointment WHERE customerid = ? ";

		
		private Connection connection = DbUtil.getConnection();
		
	    @Override
	    public List<Client> displayAllClient() throws SQLException {
	    		        List<Client> clients = new ArrayList<>();
	        Statement stmt = connection.createStatement();  
	        ResultSet rs = stmt.executeQuery(SELECT_ALL);
	        
	        while (rs.next()) {
	            Client client = new Client();
 	            client.setCutomerid(rs.getInt("customerid"));
	            client.setName(rs.getString("Name"));
	            client.setAddress(rs.getString("address"));
	            client.setPhoneNo(rs.getLong("phoneNo"));  
	            clients.add(client);
	        }
	        rs.close();
	        stmt.close();
	        return clients;
	    }
	    

	    @Override
	    public Client findById(int clientId) throws ClientNotFoundException, SQLException {
	        Client client = null;
	        PreparedStatement stmt = connection.prepareStatement(SELECT_BY_ID);
	        stmt.setInt(1, clientId);
	        ResultSet rs = stmt.executeQuery();
	        System.out.println("Rs  : "  + rs);
	        if (rs.next()) {
	            client = new Client();
	            client.setCutomerid(rs.getInt("customerid"));
	            client.setName(rs.getString("Name"));
	            client.setAddress(rs.getString("address"));
	            client.setPhoneNo(rs.getLong("phoneNo")); // Use consistent case
	        } else {
	            throw new ClientNotFoundException("Client Not Found With Id: " + clientId);
	        }
	        rs.close();
	        stmt.close();
	        return client;
	    }
	    
		@Override
		public boolean update(Client client) throws SQLException {
			PreparedStatement stmt = connection.prepareStatement(UPDATE);
			
			stmt.setString(1,client.getName() );
			stmt.setString(2,client.getAddress() );
			stmt.setLong(3, client.getPhoneNo());
			stmt.setInt(4,client.getCutomerid() );
			
			int updated = stmt.executeUpdate();
			stmt.close();
			
			return updated > 0;	
			
	}
		//@Override
		public boolean delete(Client client) throws SQLException {
			PreparedStatement stmt = connection.prepareStatement(DELETE);
	        stmt.setInt(1, client.getCutomerid());
			
			int deleted = stmt.executeUpdate();
			
			stmt.close();
			return deleted > 0;

	}

		@Override
		public boolean insert (Client client) throws SQLException {
			boolean result=false;
			PreparedStatement stmt = connection.prepareStatement(INSERT);
			stmt.setString(1,client.getName() );
			stmt.setString(2,client.getAddress() );
			stmt.setLong(3, client.getPhoneNo());
			if(stmt.executeUpdate()>0) {
				result = true;
			}
			stmt.close();
			return result;
		}

		@Override
		public List<Appointment> displayAllAppointment() throws SQLException {
			List<Appointment> appointments = new ArrayList<>();
	        Statement stmt = connection.createStatement();  
	        ResultSet rs = stmt.executeQuery(SELECT_ALL_APPOINMENT);
	        
	        while (rs.next()) {
	            Appointment appointment = new Appointment();
	            appointment.setAppid(rs.getInt("Appid"));
	            appointment.setDate(rs.getDate("date"));
	            appointment.setVehiclename(rs.getString("vehiclename"));
	            appointment.setVehiclenNO(rs.getString("vehiclenNO"));
	            appointment.setCustomername(rs.getString("customername"));
	            appointment.setServicetype(rs.getString("servicetype"));
	           
	            appointment.setCustomerid(rs.getInt("customerid"));
	            appointments.add(appointment);
	        }
	        rs.close();
	        stmt.close();
	        return appointments;
			 
		}

		
		@Override
		public Appointment appointmentfindById(int appointmentId) throws AppointmentNotFoundException, SQLException {
			Appointment appointment = null;
	        PreparedStatement stmt = connection.prepareStatement(SELECT_BY_ID_APPOINTMENT);
	        stmt.setInt(1, appointmentId);
	        ResultSet rs = stmt.executeQuery();
	        System.out.println("Rs  : "  + rs);
	        if (rs.next()) {
	        	appointment = new Appointment();
	        	appointment.setAppid(rs.getInt("appid"));
	        	appointment.setDate(rs.getDate("date"));
	            appointment.setVehiclename(rs.getString("vehiclename"));
	            appointment.setVehiclenNO(rs.getString("vehiclenNO"));
	            appointment.setCustomername(rs.getString("customername"));
	            appointment.setServicetype(rs.getString("servicetype")); 
	            appointment.setCustomerid(rs.getInt("customerid"));
	        } else {
	            throw new AppointmentNotFoundException("Appointment Not Found With Id: " + appointmentId);
	        }
	        rs.close();
	        stmt.close();
	        return appointment;
			 
		}

		
		@Override
		public boolean insertappointment(Appointment appointment) throws SQLException {
			boolean result=false;
			PreparedStatement stmt = connection.prepareStatement(INSERT_APPOINTMENT);
			stmt.setDate(1, new java.sql.Date(appointment.getDate().getTime()));
			
			stmt.setString(2,appointment.getVehiclename() );
			stmt.setString(3,appointment.getVehiclenNO() );
			stmt.setString(4,appointment.getCustomername());
			stmt.setString(5, appointment.getServicetype());
			
			stmt.setInt(6,appointment.getCustomerid() );
			if(stmt.executeUpdate()>0) {
				result = true;
			}
			stmt.close();
			return result;
			 
		}

		@Override
		public boolean updateappointment(Appointment appointment) throws SQLException {
			PreparedStatement stmt = connection.prepareStatement(UPDATE_APPOINTMENT);
			stmt.setDate(1, new java.sql.Date(appointment.getDate().getTime()));
			
			stmt.setString(2,appointment.getVehiclename() );
			stmt.setString(3,appointment.getVehiclenNO() );
			stmt.setString(4,appointment.getCustomername() );
			stmt.setString(5, appointment.getServicetype());
			stmt.setInt(6,appointment.getCustomerid());			
			int updated = stmt.executeUpdate();
			stmt.close();
			
			return updated > 0;	
			 
		}

		
		@Override
		public boolean deleteappointment(Appointment appointment) throws SQLException {
			PreparedStatement stmt = connection.prepareStatement(DELETE_APPOINTMENT);
	        stmt.setInt(1, appointment.getAppid());
			
			int deleted = stmt.executeUpdate();
			
			stmt.close();
			return deleted > 0;
			 
		}


		 

}
