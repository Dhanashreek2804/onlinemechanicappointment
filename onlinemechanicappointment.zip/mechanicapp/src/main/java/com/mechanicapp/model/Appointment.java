package com.mechanicapp.model;

import java.util.Date;

public class Appointment {
	
	private int appid;
	private Date date;
	private String vehiclename;
	private String vehiclenNO;
	private String customername;
	private String servicetype;
	private int customerid;
	
	
	
	public int getAppid() {
		return appid;
	}
	public void setAppid(int appid) {
		this.appid = appid;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getVehiclename() {
		return vehiclename;
	}
	public void setVehiclename(String vehiclename) {
		this.vehiclename = vehiclename;
	}
	public String getVehiclenNO() {
		return vehiclenNO;
	}
	public void setVehiclenNO(String vehiclenNO) {
		this.vehiclenNO = vehiclenNO;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getServicetype() {
		return servicetype;
	}
	public void setServicetype(String servicetype) {
		this.servicetype = servicetype;
	}
	public Appointment(int appid, Date date, String customername, String servicetype,
			String vehiclename) {
		//super();
		this.appid = appid;
		this.date = date;
		this.customername = customername;
		this.servicetype = servicetype;
		this.vehiclename = vehiclename;
	}
	
	public Appointment() {
		//super();
	}
	
	
	
	
	public Appointment(int appid) {
		super();
		this.appid = appid;
	}
	public Appointment(int appid,Date date,String vehiclename, String vehicleNO, String customername,
			String servicetype, int customerid) {
		//super();
		this.appid = appid;
		this.date = date;
		this.vehiclename = vehiclename;
		this.vehiclenNO = vehiclenNO;
		this.customername = customername;
		this.servicetype = servicetype;
		this.customerid = customerid;
	}
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	
	@Override
	public String toString() {
		return "Appointment [appid=" + appid + ", date=" + date + ", vehiclename=" + vehiclename + ", vehiclenNO=" + vehiclenNO + ", customername=" + customername
				+ ", servicetype=" + servicetype + ", customerid=" + customerid
				+ "]";
	}
	 
	
	 
	 

}
