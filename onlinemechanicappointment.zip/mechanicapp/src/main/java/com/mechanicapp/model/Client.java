package com.mechanicapp.model;

public class Client {
	
	private int cutomerid;
	private String name;
	private String address;
	private long phoneNo;
	
	
	 	
	public int getCutomerid() {
		return cutomerid;
	}
	public void setCutomerid(int cutomerid) {
		this.cutomerid = cutomerid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Client(int cutomerid, String name, String address, long phoneNo) {
		//super();
		this.cutomerid = cutomerid;
		this.name = name;
		this.address = address;
		this.phoneNo = phoneNo;
	}
	public Client(String name, String address, long phoneNo) {
		//super();
		this.name = name;
		this.address = address;
		this.phoneNo = phoneNo;
	}
	public Client() {
		//super();
	}
	
	
	public Client(int cutomerid) {
		//super();
		this.cutomerid = cutomerid;
	}
	@Override
	public String toString() {
		return "Client [cutomerid=" + cutomerid + ", name=" + name + ", address="
				+ address + ", phoneNo=" + phoneNo + "]";
	}
	
	 
	 
	
	
	
}
