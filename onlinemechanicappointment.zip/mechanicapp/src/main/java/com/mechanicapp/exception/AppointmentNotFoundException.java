package com.mechanicapp.exception;

public class AppointmentNotFoundException extends Exception {
	
	public AppointmentNotFoundException (String message) {
		super(message);
	}

}
